import Image from "next/image";
import Login from "./components/Login";
import styles from "./components/Login.module.css";


export default function Home() {
  return (
   <div>
    <Login />
   </div>
  );
}
